/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 13, 2017, 11:32 AM
 * Purpose: Calculates the number of points via 
 * book purchase.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main()
{
        //Declaration
	unsigned int bookPurd;

        //Input Data
	cout << "Please enter the number of books you purchased this\n"
		 << "month for monthly awarded points.\n";
	cin  >> bookPurd;
	
        //Output Data
	switch (bookPurd)// Number of points earned.
	{
	case 0  : cout << "You have earned 0 points for this month.\n";
		break;
	case 1	: cout << "You have earned 5 points for this month.\n";
		break;
	case 2	: cout << "You have earned 15 points for this month.\n";
		break;
	case 3	: cout << "You have earned 30 points for this month.\n";
		break;
	default : cout << "You have earned 60 points for this month.\n"<<endl;		
        }
        
        //Exit Stage left!
	return 0;
}



