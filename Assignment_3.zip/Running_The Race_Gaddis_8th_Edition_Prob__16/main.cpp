/* 
 * File:   main.cpp
 * Author: Yul Joseph
 * Created on March 16, 2017, 2:32 AM
 * Purpose: To determine which digit is greater. 
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <string>    //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) 

{
   //Declaration
    string runner1, 
	   runner2,
	   runner3;
    int    runTime1, runTime2, runTime3;  //Run times 

	// Data Input (Names and Time)
	cout << "To calculate the placement of the runners\n"
	     << "Input the requested information.\n";
	cout << "What is the name of the fist runner? ";
	cin  >> runner1;
	cout << "How long did " << runner1 << " take to finish the race? ";
	cin  >> runTime1;
	cout << "What is the name of the second runner? ";
	cin  >> runner2;
	cout << "How long did " << runner2 << " take to finish the race? ";
	cin  >> runTime2;
	cout << "What is the name of the third runner? ";
	cin  >> runner3;
	cout << "How long did " << runner3 << " take to finish the race? ";
	cin  >> runTime3;

	if (runTime1 > 0 && runTime2 > 0 && runTime3 > 0)
		if (runTime1 < runTime2 && runTime1 < runTime3)
			if (runTime2 < runTime3)
			{
				cout << "First place: " << runner1<<endl;
				cout << "Second place: " << runner2<<endl;
				cout << "Third place:  " << runner3 <<endl;
			}
			else 
			{
				cout << "First place: " << runner1<<endl;
				cout << "Second place: " << runner3<<endl;
				cout << "Third place:  " << runner2 <<endl;
			}
		else if (runTime2 < runTime1 && runTime2 < runTime3)
			if (runTime1 < runTime3)
			{
				cout << "First place: " << runner2<<endl;
				cout << "Second place: " << runner1<<endl;
				cout << "Third place: " << runner3 <<endl;
			}
			else
			{
				cout << "First place: " << runner2<<endl;
				cout << "Second place: " << runner3<<endl;
				cout << "Third place: " << runner1 <<endl;
			}
		else 
			if (runTime1 < runTime2)
			{
				cout << "First place: " << runner3<<endl;
				cout << "Second place: " << runner1<<endl;
				cout << "Third place: " << runner2 <<endl;
			}
			else
			{
				cout << "First place: " << runner3<<endl;
				cout << "Second place: " << runner2<<endl;
				cout << "Third place: " << runner1 <<endl;
			}
	else
		cout << "Invalid time input! Times can not be less than zero.\n"
	         << "Please run the program again with valid time values.\n";
	return 0;
        
    //Exit stage left!
   
}
