/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 16, 2017, 3:30 AM
 * This program calculates the month, day and year
 * to give the magic date.
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <iomanip>   //Input Library
using namespace std; //Name-space under which system libraries exist


//User Libraries

//Global Constants
const short mthChrg = 10;

//Function Prototypes

//Execution begins here
int main(int argc, char** argv)
{
    //Declaration
	int chkWriten;
	short bankFees;
         

	// Data Input (Number of checks written during the past month.)
	cout << "Bank fees computation for the month.\n";
	cout << "Number of checks written during the past month: ";
	cin  >> chkWriten;

	// Verification Data (Negative value not accepted.)
	if (chkWriten >= 0)
	{
		cout << fixed << showpoint << setprecision (2);
		if (chkWriten < 20)
		{
			bankFees = mthChrg + (chkWriten * 1.10);
			cout << "Bank fee for the month: $" << bankFees;
		}
		else if (chkWriten < 40)
		{
			bankFees = mthChrg + (chkWriten * 1.08);
			cout << "Bank fee for the month: $" << bankFees;
		}
		else if (chkWriten < 60)
		{
			bankFees = mthChrg + (chkWriten * 1.06);
			cout << "Bank fee for the month: $" << bankFees;
		}
		else 
		{
			bankFees = mthChrg + (chkWriten * 1.04);
			cout << "Bank fee for the month: $" << bankFees << endl;
		}
	}
	else
	{	
		cout << "Invalid input! Number of checks cannot be less then 0.\n"
	             << "Please run the program again and enter a valid number.\n";
	}
	return 0;

        //Exit stage left!
}
        
    


