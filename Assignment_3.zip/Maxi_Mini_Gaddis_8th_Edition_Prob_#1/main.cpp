/* 
 * File:   main.cpp
 * Author: Yul Joseph
 * Created on March 13, 2017, 11:32 AM
 * Purpose: To determine which digit is greater. 
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) {
    //Declare variables
    int num1, num2; //Digits to be entered 
    
    //Initialize variables
    cout << "Enter two numbers to determine which ";
    cout << "number is the smaller or which is the larger.\n";
	
    //Map inputs to outputs or process the data
    cout << "Enter the first number: "; //First digit place holder
    cin  >> num1;
    cout << "Enter the second number: ";
    cin  >> num2;
    
    //Output the transformed data
    if (num1 < num2)
	cout << num1 << " is smaller than " << num2 << ".\n";
	else
	cout << num2 << " is smaller than " << num1 << ".\n";
	return 0;
        
    //Exit stage left!
    return 0;
}
