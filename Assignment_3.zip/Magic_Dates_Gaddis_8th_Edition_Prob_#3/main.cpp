/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 15, 2017, 11:32 AM
 * This program calculates the month, day and year
 * to give the magic date.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv)
{
    //Declaration
	int month, 
            day, 
            year;

	//Data Input-Enter a month, a day, and a two digit year. 
	cout << "Enter a two digit month, a two digit day, and a two digit year,\n"
		 << "and the program will determine if the date is magic.\n";
	cout << "Enter a month: ";
	cin  >> month;
	cout << "Enter a day: ";
	cin  >> day;
	cout << "Enter a Year:";
	cin  >> year;

	// Data Calculation (If than statements)
	if (year == month * day)
		cout << "The date is magic.\n";
	else
		cout << "The date is not magic.\n";
	return 0;
}
        
    //Exit stage left!


