/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 15, 2017, 11:32 AM
 * Purpose:  This program displays which rectangle
has the greater area or if the areas are the same.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) 
{
    //Declare variables
    int num1, num2, input, sum;
    unsigned seed = time(0);       // Random seed generator
    
    //Values and Random Numbers
    	srand(seed);
	num1 = 100 + rand() % 100;
	num2 = 100 + rand() % 100;
    
    //Initialize here / Data Input
   	cout << "Enter the sum of the following numbers:\n";
	cout << "  " << num1 << endl;
	cout << "+ " << num2 << endl;
	cout << "  ___\n  ";
	cin  >> input;
        
    //Calculation / Data Output If and Else 
    	sum = num1 + num2;
	if (input == sum)
		cout << "\nCongratulations! " << input << " is the correct answer.\n";
	
            else
            
	{
		cout << "\nIncorrect answer!\n";
		cout << "  " << num1 << endl;  //First number 
	        cout << "+ " << num2 << endl;  //Second number
                cout << "  ___\n  ";
	        cout <<      sum <<endl;        //Correct answer
	}
    return 0;
        
    //Exit stage left!
}

