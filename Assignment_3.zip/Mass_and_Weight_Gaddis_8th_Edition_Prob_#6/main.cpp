/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 14, 2017, 11:32 AM
 * Purpose:  To calculate the weight of an object.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) 

{
    //Declare variables
    int weight, mass;
    
    //Initialize here / Data Input
   	cout << "Calculate the weight of an object.\n"
		 << "Enter the object's mass: ";
	cin  >> mass;
        
    //Calculation / Data Input
    	weight = mass * 9.8;
            
    //If statement begin here    
    cout << "This object weights " << weight << " newtons.\n";
	if (weight > 1000)
		cout << "It is too heavy!\n";
	else if (weight < 10)
		cout << "It is too light!\n";

    return 0;
        
    //Exit stage left!
}

