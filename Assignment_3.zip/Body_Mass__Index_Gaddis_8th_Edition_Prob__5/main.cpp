/* 
 * File:   main.cpp
 * Author: Yul Joseph
 * Created on March 18, 2017, 11:32 AM
 * Purpose: To determine Body Mass Index
 */

//System Libraries
#include <iostream>  //Input - Output Library
#include <cmath>
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) 
    
{
    //Declaration
    short weight,
	  height,
	  bmi;

	// Input Data
	cout << "Body Mass Index Calculator\n";
	cout << "Enter weight in pounds: ";
	cin  >> weight;
	cout << "Enter height in inches: ";
	cin  >> height;

	// Calculate
	bmi = weight * (703 / pow(height, 2));

	// Output Data
	cout << "Your BMI is " << bmi << endl;
	if (bmi >= 18.5 && bmi <= 25)
		cout << "You are of optimal weight.\n";
	else if (bmi >= 25)
		cout << "You are overweight.\n";
	else
		cout << "You are underweight.\n";


        return 0;
    
        //Exit stage left!
    
}
