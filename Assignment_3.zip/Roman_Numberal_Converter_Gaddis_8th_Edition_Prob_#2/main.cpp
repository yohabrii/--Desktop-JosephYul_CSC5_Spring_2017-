/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 13, 2017, 11:32 AM
 * Purpose: Converts standard numbers to Roman Numerals.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) 
{
    //Declare variables
    int num;
    
    
    //Initialize here
    cout << "Enter a number between 1 to 10 ";//Input visual
    cout << "to receive the Roman Numeral equivalent.\n";//Input visual
    cin  >> num;//Input data
    
    //Conversion 
    switch(num)    
            
    {
	case 1:  cout << "The Roman numeral for " << num << " is I.\n";
                          break;
	case 2:  cout << "The Roman numeral for " << num << " is II.\n";
		          break;
	case 3:  cout << "The Roman numeral for " << num << " is III.\n";
		          break;
	case 4:  cout << "The Roman numeral for " << num << " is IV.\n";
	                  break;
	case 5:  cout << "The Roman numeral for " << num << " is V.\n";
	                  break;
	case 6:  cout << "The Roman numeral for " << num << " is VI.\n";
		          break;
	case 7:  cout << "The Roman numeral for " << num << " is VII.\n";
		          break;
	case 8:  cout << "The Roman numeral for " << num << " is VIII.\n";
		          break;
	case 9:  cout << "The Roman numeral for " << num << " is IX.\n";
			  break;
	case 10: cout << "The Roman numeral for " << num << " is X.\n";
		          break;
	default: cout << "Error! ";
		 cout << "Cannot process numbers ";
		 cout << "less than one or greater than ten.\n"<<endl;
	}
	return 0;
       
    //Exit stage right!

    return 0;
}

