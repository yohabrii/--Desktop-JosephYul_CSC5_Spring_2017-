/* 
 * File:   main.cpp
 * Author: Yul Joseph 
 * Created on March 14, 2017, 11:32 AM
 * Purpose:  This program displays which rectangle
has the greater area or if the areas are the same.
 */

//System Libraries
#include <iostream>  //Input - Output Library
using namespace std; //Name-space under which system libraries exist

//User Libraries

//Global Constants

//Function Prototypes

//Execution begins here
int main(int argc, char** argv) 
{
    //Declare variables
    int length1, length2, width1, width2, area1, area2;
    
    
    //Initialize here / Data Input
   	cout << "This program determines which of two rectangles has\n"
		 << "the greater area, or if the areas are the same.\n";
	cout << "Enter the length and width of rectangle A:\n";
	cin  >> length1 >> width1;
	cout << "Enter the length and width of rectangle B:\n";
	cin  >> length2 >> width2;    
        
    //Calculation / Data Output
    	area1 = length1 * width1;
	area2 = length2 * width2;
    
    //If and Else statements begin here    
    if (area1 == area2)
	    cout << "The areas of both rectangle’s are the same.\n";
        else if (area1 > area2)
	    cout << "The area of rectangle A is greater than rectangle B.\n";
	else
            cout << "The area of rectangle B is greater than rectangle A.\n"<<endl;

    return 0;
        
    //Exit stage left!
}

